#!/usr/bin/env bash
set -euo pipefail
: "${MONGODB_URI:?Set MONGODB_URI before running backup}"
OUT="${1:-backups/$(date +%Y%m%d_%H%M%S)}"
mkdir -p "$OUT"
mongodump --uri="$MONGODB_URI" --out="$OUT"
echo "Backup created at $OUT"
