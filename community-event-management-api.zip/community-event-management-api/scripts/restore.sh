#!/usr/bin/env bash
set -euo pipefail
: "${MONGODB_URI:?Set MONGODB_URI before running restore}"
if [[ $# -lt 1 ]]; then echo "Usage: MONGODB_URI=... ./scripts/restore.sh <backup-directory>"; exit 1; fi
mongorestore --uri="$MONGODB_URI" --drop "$1"
echo "Restore completed from $1"
