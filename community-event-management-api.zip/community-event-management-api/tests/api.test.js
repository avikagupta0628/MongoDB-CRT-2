const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const request = require('supertest');
const app = require('../src/app');

let mongo;
before(async () => {
  mongo = await MongoMemoryServer.create();
  await mongoose.connect(mongo.getUri());
});
after(async () => {
  await mongoose.disconnect();
  if (mongo) await mongo.stop();
});

test('health endpoint responds', async () => {
  const res = await request(app).get('/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
});

test('event CRUD and registration workflow', async () => {
  const payload = {
    title: 'Park Cleanup Day',
    description: 'Help clean the central park.',
    category: 'cleanup',
    venue: 'Central Park',
    city: 'Jaipur',
    startsAt: '2027-01-10T08:00:00.000Z',
    endsAt: '2027-01-10T11:00:00.000Z',
    capacity: 1,
    organizer: 'Green Jaipur',
    status: 'published',
    tags: ['community', 'environment']
  };
  const created = await request(app).post('/api/events').send(payload);
  assert.equal(created.status, 201);
  const id = created.body.data._id;

  const listed = await request(app).get('/api/events?city=Jaipur');
  assert.equal(listed.status, 200);
  assert.equal(listed.body.pagination.total, 1);

  const reg1 = await request(app).post('/api/registrations').send({
    event: id, attendeeName: 'Asha', attendeeEmail: 'asha@example.com'
  });
  assert.equal(reg1.status, 201);
  assert.equal(reg1.body.data.status, 'confirmed');

  const reg2 = await request(app).post('/api/registrations').send({
    event: id, attendeeName: 'Ravi', attendeeEmail: 'ravi@example.com'
  });
  assert.equal(reg2.status, 201);
  assert.equal(reg2.body.data.status, 'waitlisted');

  const updated = await request(app).patch(`/api/events/${id}`).send({ venue: 'City Garden' });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.data.venue, 'City Garden');

  const cancelled = await request(app).patch(`/api/registrations/${reg1.body.data._id}/cancel`);
  assert.equal(cancelled.status, 200);
  const waitlisted = await mongoose.model('Registration').findById(reg2.body.data._id);
  assert.equal(waitlisted.status, 'confirmed');

  const deleted = await request(app).delete(`/api/events/${id}`);
  assert.equal(deleted.status, 200);
});
