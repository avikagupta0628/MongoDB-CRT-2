const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const eventRoutes = require('./routes/events');
const registrationRoutes = require('./routes/registrations');
const { notFound, errorHandler } = require('./middleware/errors');

const app = express();
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '1mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));

app.get('/health', (req, res) => res.json({ success: true, service: 'community-event-api', timestamp: new Date().toISOString() }));
app.use('/api/events', eventRoutes);
app.use('/api/registrations', registrationRoutes);
app.use(notFound);
app.use(errorHandler);
module.exports = app;
