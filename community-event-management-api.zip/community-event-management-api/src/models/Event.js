const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, default: '', maxlength: 2000 },
  category: { type: String, required: true, enum: ['cleanup', 'fundraiser', 'workshop', 'sports', 'cultural', 'other'] },
  venue: { type: String, required: true, trim: true },
  city: { type: String, required: true, trim: true, index: true },
  startsAt: { type: Date, required: true },
  endsAt: { type: Date, required: true },
  capacity: { type: Number, required: true, min: 1, max: 100000 },
  organizer: { type: String, required: true, trim: true },
  status: { type: String, enum: ['draft', 'published', 'cancelled', 'completed'], default: 'draft' },
  tags: [{ type: String, trim: true, lowercase: true }],
  registrationsCount: { type: Number, default: 0, min: 0 }
}, { timestamps: true });

eventSchema.index({ city: 1, startsAt: 1 });
eventSchema.index({ status: 1, startsAt: 1 });
eventSchema.index({ category: 1, city: 1, startsAt: 1 });
eventSchema.index({ title: 'text', description: 'text', tags: 'text' });
eventSchema.index({ startsAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 365, partialFilterExpression: { status: 'completed' } });

eventSchema.pre('validate', function(next) {
  if (this.startsAt && this.endsAt && this.endsAt <= this.startsAt) {
    this.invalidate('endsAt', 'endsAt must be later than startsAt');
  }
  next();
});

module.exports = mongoose.model('Event', eventSchema);
