const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  event: { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true },
  attendeeName: { type: String, required: true, trim: true, maxlength: 100 },
  attendeeEmail: { type: String, required: true, trim: true, lowercase: true },
  phone: { type: String, default: '' },
  status: { type: String, enum: ['confirmed', 'waitlisted', 'cancelled'], default: 'confirmed' }
}, { timestamps: true });

registrationSchema.index({ event: 1, attendeeEmail: 1 }, { unique: true });
registrationSchema.index({ attendeeEmail: 1, createdAt: -1 });
module.exports = mongoose.model('Registration', registrationSchema);
