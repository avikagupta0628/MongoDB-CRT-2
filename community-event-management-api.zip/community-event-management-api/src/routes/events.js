const express = require('express');
const mongoose = require('mongoose');
const Event = require('../models/Event');
const Registration = require('../models/Registration');
const router = express.Router();

const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// CREATE
router.post('/', asyncHandler(async (req, res) => {
  const event = await Event.create(req.body);
  res.status(201).json({ success: true, data: event });
}));

// READ: filtering, pagination, sorting and text search
router.get('/', asyncHandler(async (req, res) => {
  const { city, category, status = 'published', q, from, to } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
  const filter = {};
  if (city) filter.city = new RegExp(`^${city.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i');
  if (category) filter.category = category;
  if (status !== 'all') filter.status = status;
  if (from || to) filter.startsAt = { ...(from ? { $gte: new Date(from) } : {}), ...(to ? { $lte: new Date(to) } : {}) };
  if (q) filter.$text = { $search: q };
  const [items, total] = await Promise.all([
    Event.find(filter).sort({ startsAt: 1 }).skip((page - 1) * limit).limit(limit).lean(),
    Event.countDocuments(filter)
  ]);
  res.json({ success: true, data: items, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
}));

// READ one event
router.get('/:id', asyncHandler(async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: 'Invalid event id' });
  const event = await Event.findById(req.params.id).lean();
  if (!event) return res.status(404).json({ success: false, message: 'Event not found' });
  res.json({ success: true, data: event });
}));

// UPDATE
router.patch('/:id', asyncHandler(async (req, res) => {
  const event = await Event.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!event) return res.status(404).json({ success: false, message: 'Event not found' });
  res.json({ success: true, data: event });
}));

// DELETE (also removes dependent registrations)
router.delete('/:id', asyncHandler(async (req, res) => {
  const event = await Event.findByIdAndDelete(req.params.id);
  if (!event) return res.status(404).json({ success: false, message: 'Event not found' });
  await Registration.deleteMany({ event: event._id });
  res.json({ success: true, message: 'Event and its registrations deleted' });
}));

// Aggregation report: registrations by event
router.get('/reports/popularity', asyncHandler(async (req, res) => {
  const report = await Registration.aggregate([
    { $match: { status: { $in: ['confirmed', 'waitlisted'] } } },
    { $group: { _id: '$event', registrations: { $sum: 1 } } },
    { $lookup: { from: 'events', localField: '_id', foreignField: '_id', as: 'event' } },
    { $unwind: '$event' },
    { $project: { _id: 0, eventId: '$event._id', title: '$event.title', city: '$event.city', registrations: 1 } },
    { $sort: { registrations: -1 } },
    { $limit: 10 }
  ]);
  res.json({ success: true, data: report });
}));

module.exports = router;
