const express = require('express');
const mongoose = require('mongoose');
const Event = require('../models/Event');
const Registration = require('../models/Registration');
const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.post('/', asyncHandler(async (req, res) => {
  const { event: eventId, attendeeName, attendeeEmail, phone } = req.body;
  if (!mongoose.isValidObjectId(eventId)) return res.status(400).json({ success: false, message: 'Valid event id is required' });
  const event = await Event.findById(eventId);
  if (!event || event.status !== 'published') return res.status(404).json({ success: false, message: 'Published event not found' });
  const existing = await Registration.countDocuments({ event: eventId, status: { $in: ['confirmed', 'waitlisted'] } });
  const status = existing >= event.capacity ? 'waitlisted' : 'confirmed';
  const registration = await Registration.create({ event: eventId, attendeeName, attendeeEmail, phone, status });
  if (status === 'confirmed') await Event.updateOne({ _id: eventId }, { $inc: { registrationsCount: 1 } });
  res.status(201).json({ success: true, data: registration });
}));

router.get('/', asyncHandler(async (req, res) => {
  const filter = {};
  if (req.query.event) filter.event = req.query.event;
  if (req.query.email) filter.attendeeEmail = req.query.email.toLowerCase();
  if (req.query.status) filter.status = req.query.status;
  const data = await Registration.find(filter).populate('event', 'title startsAt city').sort({ createdAt: -1 }).limit(100);
  res.json({ success: true, data });
}));

router.patch('/:id/cancel', asyncHandler(async (req, res) => {
  const registration = await Registration.findById(req.params.id);
  if (!registration) return res.status(404).json({ success: false, message: 'Registration not found' });
  if (registration.status !== 'cancelled') {
    const wasConfirmed = registration.status === 'confirmed';
    registration.status = 'cancelled';
    await registration.save();
    if (wasConfirmed) {
      await Event.updateOne({ _id: registration.event }, { $inc: { registrationsCount: -1 } });
      const next = await Registration.findOneAndUpdate(
        { event: registration.event, status: 'waitlisted' },
        { $set: { status: 'confirmed' } },
        { sort: { createdAt: 1 }, new: true }
      );
      if (next) await Event.updateOne({ _id: registration.event }, { $inc: { registrationsCount: 1 } });
    }
  }
  res.json({ success: true, data: registration });
}));

module.exports = router;
