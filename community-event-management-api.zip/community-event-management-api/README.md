# Community Event & Volunteer Management API

A MongoDB-backed REST API for publishing community events and managing attendee registrations. This is a backend/database final-project starter with CRUD, optimized queries and indexes, replica-set deployment, backup/restore scripts, and automated tests.

## Project features

- Event CRUD: create, list/search/filter, view, update, delete.
- Registration workflow: register attendees, automatically waitlist when capacity is reached, cancel, and promote the oldest waitlisted attendee.
- MongoDB aggregation report for the ten most popular events.
- Query pagination, sorting, text search, city/category/status/date filters.
- Compound, text, unique, and supporting indexes.
- Three-member MongoDB replica set using Docker Compose.
- `mongodump` / `mongorestore` backup and restore scripts.
- API integration tests using `node:test`, Supertest, and an in-memory MongoDB.
- GitHub Actions CI workflow.

## Tech stack

Node.js 20+, Express, Mongoose, MongoDB 7, Docker Compose, Supertest.

## Run locally

1. Install Node.js 20+ and MongoDB Community Server.
2. Copy `.env.example` to `.env`.
3. Set `MONGODB_URI=mongodb://127.0.0.1:27017/community_events` in `.env`.
4. Install and run:

```bash
npm install
npm run dev
```

API base URL: `http://localhost:5000`

Health check: `GET /health`

## Run with a 3-node MongoDB replica set

Docker Compose starts three MongoDB members, initializes replica set `rs0`, then starts the API:

```bash
docker compose up --build
```

Check replica-set status:

```bash
docker compose exec mongo1 mongosh --eval "rs.status()"
```

Stop containers:

```bash
docker compose down
```

Data persists in named Docker volumes. For a clean reset only (deletes database volumes):

```bash
docker compose down -v
```

## API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/api/events` | Create event |
| GET | `/api/events` | List/filter/search events |
| GET | `/api/events/:id` | Get one event |
| PATCH | `/api/events/:id` | Update event |
| DELETE | `/api/events/:id` | Delete event and registrations |
| GET | `/api/events/reports/popularity` | Top 10 events by registrations |
| POST | `/api/registrations` | Register attendee |
| GET | `/api/registrations` | List registrations |
| PATCH | `/api/registrations/:id/cancel` | Cancel and promote waitlist |

### Event query examples

```http
GET /api/events?city=Jaipur&category=cleanup
GET /api/events?status=all&page=1&limit=20
GET /api/events?q=park cleanup
GET /api/events?from=2027-01-01&to=2027-02-01
GET /api/events/reports/popularity
```

### Create event example

```json
{
  "title": "Park Cleanup Day",
  "description": "Help clean the central park.",
  "category": "cleanup",
  "venue": "Central Park",
  "city": "Jaipur",
  "startsAt": "2027-01-10T08:00:00.000Z",
  "endsAt": "2027-01-10T11:00:00.000Z",
  "capacity": 50,
  "organizer": "Green Jaipur",
  "status": "published",
  "tags": ["community", "environment"]
}
```

### Register attendee example

```json
{
  "event": "REPLACE_WITH_EVENT_ID",
  "attendeeName": "Asha Sharma",
  "attendeeEmail": "asha@example.com",
  "phone": "9876543210"
}
```

## MongoDB indexes and performance

Indexes are declared in `src/models/Event.js` and `src/models/Registration.js`:

| Index | Purpose |
|---|---|
| `{ city: 1, startsAt: 1 }` | City event listings ordered by start time |
| `{ status: 1, startsAt: 1 }` | Published/upcoming event queries |
| `{ category: 1, city: 1, startsAt: 1 }` | Category + city + date filtering |
| Text index on title/description/tags | Keyword search |
| `{ event: 1, attendeeEmail: 1 }` unique | Prevent duplicate attendee registration |
| `{ attendeeEmail: 1, createdAt: -1 }` | Find attendee history |

Inspect query plans in mongosh:

```javascript
db.events.find({ city: "Jaipur", status: "published" })
  .sort({ startsAt: 1 }).explain("executionStats")
```

Review `executionStats.totalDocsExamined`, `totalKeysExamined`, and the winning plan. Indexes should be validated against the actual workload; extra indexes increase write and storage cost.

## Replication and backup strategy

- The Compose environment uses a three-member replica set (`rs0`) so MongoDB can elect a primary if one member becomes unavailable.
- Replica-set replication is not a backup: accidental deletes and logical corruption can replicate too.
- Take periodic logical backups with MongoDB Database Tools installed:

```bash
export MONGODB_URI='mongodb://localhost:27017/community_events?replicaSet=rs0'
chmod +x scripts/*.sh
./scripts/backup.sh
```

Restore to the target database (this overwrites matching collections):

```bash
export MONGODB_URI='mongodb://localhost:27017/community_events?replicaSet=rs0'
./scripts/restore.sh backups/YYYYMMDD_HHMMSS
```

Recommended production policy: daily backups, retain 7 daily + 4 weekly copies, encrypt off-host copies, restrict credentials, and perform a restore drill monthly. Store backup files outside the application repository.

## Testing

```bash
npm install
npm test
```

The integration test covers health, event CRUD, filtering, capacity-based waitlisting, cancellation/promotion, and deletion. The test suite launches a temporary in-memory MongoDB instance; the first run may download its MongoDB binary.

## Deployment

### Docker (recommended for demonstration)

```bash
docker compose up --build -d
docker compose ps
curl http://localhost:5000/health
```

For a public deployment, use a managed MongoDB replica set (e.g. MongoDB Atlas), set `MONGODB_URI` as a deployment secret, and deploy the Node container to Render, Railway, Fly.io, or another container host. Do not expose database credentials or commit `.env`.

### GitHub upload

1. Create a new GitHub repository named `community-event-management-api`.
2. Extract this ZIP.
3. Run `git init`, `git add .`, and `git commit -m "Initial project"`.
4. Add your GitHub repository as `origin` and push to `main`.

## Suggested project demonstration

1. Start the API and show `/health`.
2. Create an event using Postman/Thunder Client.
3. List events using city/category filters and pagination.
4. Register attendees until capacity is reached; show a waitlisted registration.
5. Cancel a confirmed registration and show waitlist promotion.
6. Run the popularity aggregation report.
7. Show indexes and an `explain("executionStats")` query plan.
8. Show `rs.status()` and run a backup.

## Important notes / possible extensions

This is an educational project, not a production-ready ticketing platform. Before production, add authentication/authorization, rate limiting, stronger email validation, transactional handling for registration concurrency, structured logging, monitoring, and secure secret management. For strict consistency under simultaneous registrations, use a MongoDB transaction and an atomic capacity check.
